import React, {useRef, useState} from 'react';
import {
  requireNativeComponent,
  UIManager,
  Platform,
  ViewStyle,
  StyleSheet,
  View,
  Text,
  NativeSyntheticEvent,
} from 'react-native';

const LINKING_ERROR =
  `The package 'ARView' doesn't seem to be linked. Make sure: \n\n` +
  Platform.select({ios: "- You have run 'pod install'\n", default: ''}) +
  '- You rebuilt the app after installing the package\n' +
  '- You are not using Expo Go\n';

type ARViewProps = {
  style: ViewStyle;
  onDistanceChange: (event: NativeSyntheticEvent<{distance: number; status: string}>) => void;
};

const ComponentName = Platform.select({
  ios: 'ARViewManager', // Name of the iOS ViewManager
  android: 'ARView', // Name of the Android ViewManager
  default: 'ARView',
});

const ARViewNative =
  UIManager.getViewManagerConfig(ComponentName) != null
    ? requireNativeComponent<ARViewProps>(ComponentName)
    : () => {
        throw new Error(LINKING_ERROR);
      };

const ARMeasurementView = () => {
  const [distance, setDistance] = useState(0);
  const [status, setStatus] = useState('Tap to place start point');

  const onDistanceChange = (
    event: NativeSyntheticEvent<{distance: number; status: string}>,
  ) => {
    const {distance: newDistance, status: newStatus} = event.nativeEvent;
    setDistance(newDistance);
    setStatus(newStatus);
  };

  return (
    <View style={styles.container}>
      <ARViewNative style={styles.arView} onDistanceChange={onDistanceChange} />
      <View style={styles.overlay}>
        <Text style={styles.statusText}>{status}</Text>
        {distance > 0 && (
          <Text style={styles.distanceText}>
            Distance: {distance.toFixed(2)} meters
          </Text>
        )}
        <Text style={styles.instructionText}>
          Tap on a surface to place the start and end points.
        </Text>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  arView: {
    flex: 1,
  },
  overlay: {
    position: 'absolute',
    top: 50,
    left: 0,
    right: 0,
    backgroundColor: 'rgba(0,0,0,0.5)',
    padding: 10,
    alignItems: 'center',
  },
  statusText: {
    color: 'white',
    fontSize: 18,
    fontWeight: 'bold',
  },
  distanceText: {
    color: 'yellow',
    fontSize: 24,
    fontWeight: 'bold',
    marginTop: 5,
  },
  instructionText: {
    color: 'white',
    fontSize: 14,
    marginTop: 10,
  },
});

export default ARMeasurementView;
